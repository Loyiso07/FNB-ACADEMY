my_tuple=(1,2,3,4)
print(my_tuple[0])
print(my_tuple[2])

tuple1=(1,2,3)
tuple2=(4,5,6)
rep=tuple1*3
print(tuple1+tuple2)
print(rep)