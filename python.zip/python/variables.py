myvariable=25
total_count=0
user="john"
