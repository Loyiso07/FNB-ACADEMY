Foods=[]
Prices=[]
total=0
while True:
    Food=input("Please eneter food: ")
    if Food.lower()=="q":
        break
    else:
        Price=float(input(f"Enter price of {Food}:R"))
        Foods.append(Food)
        Prices.append(Price)
        
print("---Your cart is----")
for Food in Foods:
    print(Food)
for Price in Prices:
    total+=Price
    
print("Your total is R",total)