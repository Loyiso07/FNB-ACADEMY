Fruits=["banana","Apple","Peach","Orange"]
Numbers=[1,2,3,4,5]
for fruit in Fruits:
    print(fruit)
for number in Numbers:
    print(number)
    num=2
while num<=10:
    print(num)
    num+=1
    
for fruit in Fruits:
    if fruit=="Peach":
        break
    print(fruit)
for number in Numbers:
    if number==3:
        continue
    print(number)
    num=2 