my_dictionary={'apple':3,'banana':5,'Grape':2}
print(my_dictionary['apple'])
my_dictionary['Kiwi']=6
print(my_dictionary)
my_dictionary['apple']=1