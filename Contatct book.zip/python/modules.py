import mathop
import math
import datetime
import random
import sys
import os
'''print(mathop.add(2,3))
print(mathop.subtract(10,2))
print(mathop.multiply(5,5))'''
print(math.pi)
print(datetime.datetime.now())
print(random.randint(1,100))
print(sys.version)
print(os.getcwd)