x=10
y=2
print(x**y)
print(x%3)
#** exponent
#Operators with strings
Str= "hello"
str2='py'
print(Str*3)

#Control statements 
num=10
if num>0 :
    print("Positive number")
elif num==0:
    print("zero")
else:
    print("negative number")
    
     
     
#Part 2
num3=int(input("please enter a number: "))
num4= int(input("Please enter a number: "))
if num3>num4:
    print(num3,"Is greater then",num4)
elif num4>num3:
    print(num4,"Is greater then",num3)
else:
    print("numbers are equal")