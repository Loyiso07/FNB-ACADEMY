def greeting(name):
    print(f"Hi my name is {name}...")
    
print(greeting('Loyiso')) 
def add(num1,num2):
    return num1+num2

print(add(5,6))

def factorial(n):
    if n==0:
        return 1
    else:
        return factorial(n-1)*n 
    
print(factorial(0.))