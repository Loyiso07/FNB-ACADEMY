import calc
Len=float(input("Please enter the length"))
breadth=float(input("Please enter the breadth"))
print(f'The perimeterof the rectangle is:  {calc.Perimeter(Len,breadth)}')
print(f'The area of the rectangle is: {calc.Area(Len,breadth)}')
