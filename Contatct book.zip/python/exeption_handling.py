x=1
try:
    print(x)
    
except NameError:
    print("Variable is not defined")
else:
    print('Something went wrong')
    
finally:
    print("The 'try execpt' is complete")
    
x=-2
if x<0 :
    raise Exception("Enter a number greater than zero")