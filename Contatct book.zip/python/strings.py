#Strings
#message= ' Hello world '
#print(message)
#print(len(message.strip()))
#print(message.upper())

#numeric data
num=3
print(type(num))
num2=3.14
print(type(num2))