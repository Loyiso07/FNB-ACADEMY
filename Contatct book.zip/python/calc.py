def Area(Len,breadth):
    return Len*breadth
def Perimeter(Len,breadth):
    return (Len*2)+(breadth*2)